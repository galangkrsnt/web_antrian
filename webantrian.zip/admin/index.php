<?php
$index = "active";
include('header.php');

?>
<br>
<h2 style="color:white" class="text-center">SELAMAT DATANG</h2>
<?php
include('footer.php');
?>